package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.mie.model.Ingredient;
import com.mie.util.DbUtil;

public class IngredientDao {

	private Connection connection;

	public IngredientDao() {
		connection = DbUtil.getConnection();
	}

	public void addIngredient(Ingredient ingredient) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Ingredients(IngredientID,Name,Grams,Calories,Carbohydrate,Cholesterol,Sodium,Sugar,Fat,Protein,gluten,VitaminA,VitaminB,VitaminC,VitaminD,VitaminE,VitaminK,FolicAcid,Calcium,Iron,Zinc,Potassium,Magnesium) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setInt(1, ingredient.getIngredientID());
			preparedStatement.setString(2, ingredient.getName());
			preparedStatement.setInt(3, ingredient.getGrams());
			preparedStatement.setInt(4, ingredient.getCalories());
			preparedStatement.setDouble(5, ingredient.getCarbohydrate());
			preparedStatement.setDouble(6, ingredient.getCholesterol());
			preparedStatement.setDouble(7, ingredient.getSodium());
			preparedStatement.setDouble(8, ingredient.getSugar());
			preparedStatement.setDouble(9, ingredient.getFat());
			preparedStatement.setDouble(10, ingredient.getProtein());
			preparedStatement.setBoolean(11, ingredient.getGluten());
			preparedStatement.setBoolean(12, ingredient.getVA());
			preparedStatement.setBoolean(13, ingredient.getVB());
			preparedStatement.setBoolean(14, ingredient.getVC());
			preparedStatement.setBoolean(15, ingredient.getVD());
			preparedStatement.setBoolean(16, ingredient.getVE());
			preparedStatement.setBoolean(17, ingredient.getVK());
			preparedStatement.setBoolean(18, ingredient.getFolicAcid());
			preparedStatement.setBoolean(19, ingredient.getCalcium());
			preparedStatement.setBoolean(20, ingredient.getIron());
			preparedStatement.setBoolean(21, ingredient.getZinc());
			preparedStatement.setBoolean(22, ingredient.getMagnesium());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteIngredient(int ingID) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from Ingredients where IngredientID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, ingID);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateIngredient(Ingredient ingredient) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(
							"update Ingredients set Name=?, Grams=?, Calories=?, Carbohydrate=?, Cholesterol=?, Sodium=?, Sugar=?, Fat=?, Protein=?, gluten=?, VitaminA=?, VitaminB=?, VitaminC=?, VitaminD=?, VitaminE=?, VitaminK=?, FolicAcid=?, Calcium=?, Iron=?, Zinc=?, Potassium=?, Magnesium=? where IngredientID=?"
					);
			// Parameters start with 1
			preparedStatement.setString(1, ingredient.getName());
			preparedStatement.setInt(2, ingredient.getGrams());
			preparedStatement.setInt(3, ingredient.getCalories());
			preparedStatement.setDouble(4, ingredient.getCarbohydrate());
			preparedStatement.setDouble(5, ingredient.getCholesterol());
			preparedStatement.setDouble(6, ingredient.getSodium());
			preparedStatement.setDouble(7, ingredient.getSugar());
			preparedStatement.setDouble(8, ingredient.getFat());
			preparedStatement.setDouble(9, ingredient.getProtein());
			preparedStatement.setBoolean(10, ingredient.getGluten());
			preparedStatement.setBoolean(11, ingredient.getVA());
			preparedStatement.setBoolean(12, ingredient.getVB());
			preparedStatement.setBoolean(13, ingredient.getVC());
			preparedStatement.setBoolean(14, ingredient.getVD());
			preparedStatement.setBoolean(15, ingredient.getVE());
			preparedStatement.setBoolean(16, ingredient.getVK());
			preparedStatement.setBoolean(17, ingredient.getFolicAcid());
			preparedStatement.setBoolean(18, ingredient.getCalcium());
			preparedStatement.setBoolean(19, ingredient.getIron());
			preparedStatement.setBoolean(20, ingredient.getZinc());
			preparedStatement.setBoolean(21, ingredient.getMagnesium());
			preparedStatement.setInt(22, ingredient.getIngredientID());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Ingredient> getAllIngredients() {
		List<Ingredient> ing = new ArrayList<Ingredient>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Ingredients");
			while (rs.next()) {
				Ingredient ingredient = new Ingredient();
				ingredient.setIngredientID(rs.getInt("IngredientID"));
				ingredient.setName(rs.getString("Name"));
				ingredient.setGrams(rs.getInt("Grams"));
				ingredient.setCalories(rs.getInt("Calories"));
				ingredient.setCarbohydrate(rs.getDouble("Carbohydrate"));
				ingredient.setCholesterol(rs.getDouble("Cholesterol"));
				ingredient.setSodium(rs.getDouble("Sodium"));
				ingredient.setSugar(rs.getDouble("Sugar"));
				ingredient.setFat(rs.getDouble("Fat"));
				ingredient.setProtein(rs.getDouble("Protein"));
				ingredient.setGluten(rs.getBoolean("gluten"));
				ingredient.setVA(rs.getBoolean("VitaminA"));
				ingredient.setVB(rs.getBoolean("VitaminB"));
				ingredient.setVC(rs.getBoolean("VitaminC"));
				ingredient.setVD(rs.getBoolean("VitaminD"));
				ingredient.setVE(rs.getBoolean("VitaminE"));
				ingredient.setVK(rs.getBoolean("VitaminK"));
				ingredient.setFolicAcid(rs.getBoolean("FolicAcid"));
				ingredient.setCalcium(rs.getBoolean("Calcium"));
				ingredient.setIron(rs.getBoolean("Iron"));
				ingredient.setZinc(rs.getBoolean("Zinc"));
				ingredient.setPotassium(rs.getBoolean("Potassium"));
				ingredient.setMagnesium(rs.getBoolean("Magnesium"));
				ing.add(ingredient);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ing;
	}

	public Ingredient getIngredientById(int id) {
		Ingredient ingredient = new Ingredient();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Ingredient where IngredientID=?");
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				ingredient.setIngredientID(rs.getInt("IngredientID"));
				ingredient.setName(rs.getString("Name"));
				ingredient.setGrams(rs.getInt("Grams"));
				ingredient.setCalories(rs.getInt("Calories"));
				ingredient.setCarbohydrate(rs.getDouble("Carbohydrate"));
				ingredient.setCholesterol(rs.getDouble("Cholesterol"));
				ingredient.setSodium(rs.getDouble("Sodium"));
				ingredient.setSugar(rs.getDouble("Sugar"));
				ingredient.setFat(rs.getDouble("Fat"));
				ingredient.setProtein(rs.getDouble("Protein"));
				ingredient.setGluten(rs.getBoolean("gluten"));
				ingredient.setVA(rs.getBoolean("VitaminA"));
				ingredient.setVB(rs.getBoolean("VitaminB"));
				ingredient.setVC(rs.getBoolean("VitaminC"));
				ingredient.setVD(rs.getBoolean("VitaminD"));
				ingredient.setVE(rs.getBoolean("VitaminE"));
				ingredient.setVK(rs.getBoolean("VitaminK"));
				ingredient.setFolicAcid(rs.getBoolean("FolicAcid"));
				ingredient.setCalcium(rs.getBoolean("Calcium"));
				ingredient.setIron(rs.getBoolean("Iron"));
				ingredient.setZinc(rs.getBoolean("Zinc"));
				ingredient.setPotassium(rs.getBoolean("Potassium"));
				ingredient.setMagnesium(rs.getBoolean("Magnesium"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ingredient;
	}
	
	public List<Ingredient> getIngredientByKeyword(String keyword) {
		List<Ingredient> ingredients = new ArrayList<Ingredient>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from ingredients where name LIKE ?");
			
//			SELECT title FROM pages WHERE my_col LIKE %$param1% OR another_col LIKE %$param2%;
			
			preparedStatement.setString(1, "%" + keyword + "%");

			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Ingredient ingredient = new Ingredient();
				
				ingredient.setIngredientID(rs.getInt("IngredientID"));
				ingredient.setName(rs.getString("Name"));
				ingredient.setGrams(rs.getInt("Grams"));
				ingredient.setCalories(rs.getInt("Calories"));
				ingredient.setCarbohydrate(rs.getDouble("Carbohydrate"));
				ingredient.setCholesterol(rs.getDouble("Cholesterol"));
				ingredient.setSodium(rs.getDouble("Sodium"));
				ingredient.setSugar(rs.getDouble("Sugar"));
				ingredient.setFat(rs.getDouble("Fat"));
				ingredient.setProtein(rs.getDouble("Protein"));
				ingredient.setGluten(rs.getBoolean("gluten"));
				ingredient.setVA(rs.getBoolean("VitaminA"));
				ingredient.setVB(rs.getBoolean("VitaminB"));
				ingredient.setVC(rs.getBoolean("VitaminC"));
				ingredient.setVD(rs.getBoolean("VitaminD"));
				ingredient.setVE(rs.getBoolean("VitaminE"));
				ingredient.setVK(rs.getBoolean("VitaminK"));
				ingredient.setFolicAcid(rs.getBoolean("FolicAcid"));
				ingredient.setCalcium(rs.getBoolean("Calcium"));
				ingredient.setIron(rs.getBoolean("Iron"));
				ingredient.setZinc(rs.getBoolean("Zinc"));
				ingredient.setPotassium(rs.getBoolean("Potassium"));
				ingredient.setMagnesium(rs.getBoolean("Magnesium"));
				ingredients.add(ingredient);
				
//				User user = new User();
//				user.setUserid(rs.getInt("userid"));
//				user.setFirstName(rs.getString("firstname"));
//				user.setLastName(rs.getString("lastname"));
//				user.setDob(rs.getDate("dob"));
//				user.setEmail(rs.getString("email"));
//				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ingredients;
	}

	
}