package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.RecipeDao;
import com.mie.model.Recipe;

public class RecipeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/user.jsp";
	private static String LIST_RECIPE = "/recipe.jsp";
	private static String SEARCH_FNAME_USER = "/searchFNUser.jsp";
	private RecipeDao dao;

	public RecipeController() {
		super();
		dao = new RecipeDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("delete")) {
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			dao.deleteUser(userId);
//			forward = LIST_USER;
//			request.setAttribute("users", dao.getAllUsers());
		} else if (action.equalsIgnoreCase("edit")) {
			forward = INSERT_OR_EDIT;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
		} else if (action.equalsIgnoreCase("listRecipe")) {
			forward = LIST_RECIPE;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
//			request.setAttribute("recipes", dao.getAllRecipes());
		} else {
			forward = INSERT_OR_EDIT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Recipe recipe = new Recipe();
		recipe.setName(request.getParameter("name"));
		
//		user.setLastName(request.getParameter("lastName"));
//		try {
//			Date dob = new SimpleDateFormat("MM/dd/yyyy").parse(request
//					.getParameter("dob"));
//			user.setDob(dob);
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//		user.setEmail(request.getParameter("email"));
		
		String recipeid = request.getParameter("recipeid");
		if (recipeid == null || recipeid.isEmpty()) {
			dao.addRecipe(recipe);
		} else {
			recipe.setRecipeID(Integer.parseInt(recipeid));
			dao.updateRecipe(recipe); //TODO
		}
		RequestDispatcher view = request.getRequestDispatcher(LIST_RECIPE);
		request.setAttribute("recipes", dao.getAllRecipes());
		view.forward(request, response);
	}
}