package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.mie.model.Ingredient;
import com.mie.model.Recipe;
import com.mie.util.DbUtil;

public class RecipesIngredientsDao {

	private Connection connection;

	public RecipesIngredientsDao() {
		connection = DbUtil.getConnection();
	}
	
	public void addIngredientToRecipe(int ingredientId, int recipeId) {
		
	}
	
	public void deleteIngredientFromRecipe(int ingredientId, int recipeId) {
		
	}
	
	public List<Ingredient> getAllIngredientsInRecipe(int storeId) {
		
	}
	
	public List<Recipe> getAllRecipesWithIngredient(int ingredientId) {
		
	}
}
