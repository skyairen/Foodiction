package com.mie.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import com.mie.dao.IngredientDao;

public class IngredientList implements Iterable<Ingredient>{
	private ArrayList<Ingredient> ingredientList = new ArrayList<Ingredient>();

	@Override
	public Iterator<Ingredient> iterator() {
		// TODO Auto-generated method stub
		return ingredientList.iterator();
	}
	public void add(Ingredient ingredient) {
		ingredientList.add(ingredient);
	}

	// returns the number of elements stored in the DeansList object
	public int size() {
		return ingredientList.size();
	}

	// checks if the DeansList object is empty and returns a boolean (true if
	// empty)
	public boolean isEmpty() {
		return ingredientList.isEmpty();
	}
	
}
