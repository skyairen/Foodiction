package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.RecipeDao;
import com.mie.model.Recipe;

import com.mie.dao.IngredientDao;
import com.mie.model.Ingredient;


public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/recipe.jsp";
	private static String LIST_USER = "/listRecipe.jsp";
	private static String SEARCH_RECIPE_INGREDIENT = "/search_results.jsp";
	private RecipeDao rDao;
	private IngredientDao iDao;


	public SearchController() {
		super();
		rDao = new RecipeDao();
		iDao = new IngredientDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		
		

		if (action.equalsIgnoreCase("seeAll")) {
			forward = SEARCH_RECIPE_INGREDIENT;
			
			String keyword = request.getParameter("keyword");
			request.setAttribute("keyword", keyword);
			request.setAttribute("ingredients", iDao.getIngredientByKeyword(keyword));
			request.setAttribute("recipes", rDao.getRecipeByKeyword(keyword));
		}
//		if (action.equalsIgnoreCase("delete")) {
//			int recipeID = Integer.parseInt(request.getParameter("recipeId"));
//			dao.deleteRecipe(recipeID);
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else if (action.equalsIgnoreCase("edit")) {
//			forward = INSERT_OR_EDIT;
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			User user = dao.getUserById(userId);
//			request.setAttribute("user", user);
//		} else if (action.equalsIgnoreCase("listRecipe")) {
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else {
//			forward = "";
//		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}
		

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		Recipe recipe = new Recipe();
		recipe.setName(request.getParameter("name"));
		
		Ingredient ingredient = new Ingredient();
		ingredient.setName(request.getParameter("name"));
		
		String keyword = request.getParameter("keyword");
		
		RequestDispatcher view = request.getRequestDispatcher(SEARCH_RECIPE_INGREDIENT);
		request.setAttribute("keyword", keyword);
		
		request.setAttribute("ingredients", iDao.getIngredientByKeyword(keyword));
		request.setAttribute("recipes", rDao.getRecipeByKeyword(keyword));
		view.forward(request, response);
		
//		request.setAttribute("recipes", rDao.getRecipeByKeyword(keyword));
//		view2.forward(request, response);
	}
}