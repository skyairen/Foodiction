package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.IngredientStoresDao;
import com.mie.dao.RecipeDao;
import com.mie.dao.RecipesIngredientsDao;
import com.mie.dao.StoresDao;
import com.mie.dao.UserDao;
import com.mie.dao.UserRecipesDao;
import com.mie.model.Recipe;
import com.mie.model.Store;
import com.mie.model.User;
import com.mie.dao.IngredientDao;


public class IngredientStoresController extends HttpServlet {
	private static final long serialVersionUID = 1L;
//	private static String INSERT_OR_EDIT = "/recipe.jsp";
//	private static String LIST_USER = "/listRecipe.jsp";
	private static String WTB = "/wheretobuy.jsp";
	private IngredientDao idao;
	private UserDao udao;
	private StoresDao sdao;
	private IngredientStoresDao isdao;

	public IngredientStoresController() {
		super();
		idao = new IngredientDao();
		udao = new UserDao();
		sdao = new StoresDao();
		isdao = new IngredientStoresDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		HttpSession session = request.getSession();
		
		if (action.equalsIgnoreCase("whereToBuy")) {
			forward = WTB;
			String username = (String) session.getAttribute("loginValue");	//find user
			request.setAttribute("username", username);
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));

			User user = new User();
			user = udao.getUserByUsername(username); //retrieve user attributes
			int location = user.getLocation(); //get user's location
			
			Store store = sdao.getClosestStore(location);
			request.setAttribute("store", store); //save stores
			request.setAttribute("ips",isdao.getClosestIngredients(recipeId, store));
			
		}

//		if (action.equalsIgnoreCase("delete")) {
//			int recipeID = Integer.parseInt(request.getParameter("recipeId"));
//			dao.deleteRecipe(recipeID);
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else if (action.equalsIgnoreCase("edit")) {
//			forward = INSERT_OR_EDIT;
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			User user = dao.getUserById(userId);
//			request.setAttribute("user", user);
//		} else if (action.equalsIgnoreCase("listRecipe")) {
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else {
//			forward = "";
//		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}
		

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
//		Recipe recipe = new Recipe();
//		recipe.setName(request.getParameter("name"));
//		
//		String keyword = request.getParameter("keyword");
//		
//		RequestDispatcher view = request.getRequestDispatcher(SEARCH_FOOD_TYPE);
//		request.setAttribute("keyword", keyword);
//		
//		request.setAttribute("recipes", rDao.getRecipeByFoodType(keyword));
//		view.forward(request, response);

	}
}