package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.UserDao;
import com.mie.model.User;

public class SignUpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
//	private static String INSERT_OR_EDIT = "/user.jsp";
	private static String LIST_USER = "/tell_more.jsp";
	private static String TRY_AGAIN = "/sign_up_error.jsp";
	private static String THANK_YOU = "/sign_up_success.jsp";
	private UserDao dao;

	public SignUpController() {
		super();
		dao = new UserDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");

//		if (action.equalsIgnoreCase("delete")) {
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			dao.deleteUser(userId);
//			forward = LIST_USER;
//			request.setAttribute("users", dao.getAllUsers());
//		} else if (action.equalsIgnoreCase("edit")) {
//			forward = INSERT_OR_EDIT;
//			String username = request.getParameter("username");
//			User user = dao.getUserByUsername(username);
//			request.setAttribute("user", user);
//		} else if (action.equalsIgnoreCase("listUser")) {
//			forward = LIST_USER;
//			request.setAttribute("users", dao.getAllUsers());
//		} else {
//			forward = INSERT_OR_EDIT;
//		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		User trial = new User();
		trial.setEmail(request.getParameter("email"));
		trial.setUsername(request.getParameter("username"));
		trial.setPassword(request.getParameter("password"));
		if (request.getParameter("email").isEmpty() == false && request.getParameter("username").isEmpty() == false 
				&& request.getParameter("password").isEmpty() == false) {
			List<User> existing = dao.getAllUsers();
			boolean checkEmail = dao.checkEmail(existing, trial.getEmail());
			boolean checkUsername = dao.checkUsername(existing, trial.getusername());
//			these check's don't work
			if (!checkEmail && !checkUsername) {
				request.setAttribute("emailEntered", trial.getEmail());
				request.setAttribute("usernameEntered", trial.getusername());
				request.setAttribute("passwordEntered", trial.getpassword());
				RequestDispatcher view = request.getRequestDispatcher(LIST_USER);
				view.forward(request, response);
			}
			else {
				RequestDispatcher view = request.getRequestDispatcher(TRY_AGAIN);
				view.forward(request, response);
			}
		}
		else {
			RequestDispatcher view = request.getRequestDispatcher(TRY_AGAIN);
			view.forward(request, response);
		}
		
	}
}