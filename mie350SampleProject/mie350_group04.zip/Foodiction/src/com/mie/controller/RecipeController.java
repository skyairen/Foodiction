package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.RecipeDao;
import com.mie.dao.RecipesIngredientsDao;
import com.mie.dao.StoresDao;
import com.mie.dao.UserDao;
import com.mie.dao.UserRecipesDao;
import com.mie.model.Recipe;
import com.mie.model.User;
import com.mie.dao.IngredientDao;

public class RecipeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/user.jsp";
	private static String LIST_RECIPE = "/recipe.jsp";
	private static String SEARCH_FNAME_USER = "/searchFNUser.jsp";
	private static String MY_STAR = "/my_star.jsp";
	private static String MY_UPLOAD = "/my_upload.jsp";
	private static String WTB = "wheretobuy.jsp";
//	Post ones (for Carol)
	private static String THANK_YOU = "/thankyou.jsp";
	private static String RECIPE_ERROR = "/upload_recipe_error.jsp";
	private static String THANK_YOU2 = "/thankyou2.jsp";
	private static String ERROR = "/error.jsp";
	private static String RATE = "/rated.jsp";
	private static String EDIT_NOW = "edit_recipe.jsp";
	private static String UN_SAVE = "/unsave.jsp";
	private static String DELETE = "/delete.jsp";
	private static String NOT_LI = "/not_logged_in.jsp";
	private RecipeDao dao;
	private UserRecipesDao URdao;
	private RecipesIngredientsDao ridao;
	private IngredientDao idao;


	public RecipeController() {
		super();
		dao = new RecipeDao();
		URdao = new UserRecipesDao();
		ridao = new RecipesIngredientsDao();
		idao = new IngredientDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		HttpSession session = request.getSession();

		if (action.equalsIgnoreCase("editRecipe")){
			forward = EDIT_NOW;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
		} else if (action.equalsIgnoreCase("edit")) {
			forward = INSERT_OR_EDIT;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
		} else if (action.equalsIgnoreCase("listRecipe")) {
			forward = LIST_RECIPE;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
			request.setAttribute("ingredient", ridao.getAllIngredientsInRecipe(recipeId));
			double Rating = dao.getRecipeRating(recipeId);
			request.setAttribute("Rating", Rating);
//			request.setAttribute("recipes", dao.getAllRecipes());
		} else if(action.equalsIgnoreCase("ListMyStar")) {
			forward = MY_STAR;
			String Username = (String) session.getAttribute("loginValue");	
			request.setAttribute("mystars", URdao.getMyStars(Username));
			
		} else if(action.equalsIgnoreCase("ListMyUpload")) {
			forward = MY_UPLOAD;
			String Username = (String) session.getAttribute("loginValue");	
			request.setAttribute("myuploads", URdao.getMyUploads(Username));
			
		}else if(action.equalsIgnoreCase("SaveRecipe")) {
			String Username = (String) session.getAttribute("loginValue");	
			if (Username != null) {
				int recipeId = Integer.parseInt(request.getParameter("recipeID"));
				int Saved = URdao.SaveRecipe(Username, recipeId);
				System.out.println(Saved);
					if (Saved == 1){
						forward = THANK_YOU2;
					}
					else {
						forward = ERROR;
					}
			} else {
				forward = NOT_LI;
			}	
		}
		else if(action.equalsIgnoreCase("RateIt")) {
			String Username = (String) session.getAttribute("loginValue");	
			if (Username != null) {
				int recipeId = Integer.parseInt(request.getParameter("recipeID"));
				int Rating = Integer.parseInt(request.getParameter("RateIt"));
				URdao.RateRecipe(Username,recipeId,Rating);
				forward = RATE;
			} else {
				forward = NOT_LI;
			}
		}else if(action.equalsIgnoreCase("UnSave")){
			String Username = (String) session.getAttribute("loginValue");
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			URdao.UnSave(Username,recipeId);
			forward = UN_SAVE;
			
		}else if(action.equalsIgnoreCase("DeleteRecipe")){
			String Username = (String) session.getAttribute("loginValue");
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			URdao.DeleteRecipe(Username,recipeId);
			forward = DELETE;
		} else {
			forward = INSERT_OR_EDIT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}


	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("upload").isEmpty() == false) {
			HttpSession session = request.getSession();
	//		Must have name, ingredients, food type, and directions AT LEAST
			if (request.getParameter("name").isEmpty() == true || 
					request.getParameter("directions").isEmpty() == true || 
					request.getParameter("ingredients").isEmpty() == true || 
					request.getParameter("foodType").isEmpty() == true) {
				RequestDispatcher view = request.getRequestDispatcher(RECIPE_ERROR);
				view.forward(request, response);
			}
			else {
				Recipe recipe = new Recipe();
				recipe.setName(request.getParameter("name"));
				recipe.setFoodType(request.getParameter("foodType"));
				recipe.setDirections(request.getParameter("directions"));
	//			still need to add ingredient -> later
				if (request.getParameter("servings").isEmpty() == false) {
					int s = Integer.parseInt(request.getParameter("servings"));
					recipe.setServings(s);
				}
				if (request.getParameter("prepTimeMinutes").isEmpty() == false) {
					int s = Integer.parseInt(request.getParameter("prepTimeMinutes"));
					recipe.setPrepTimeMinutes(s);
				}
				if (request.getParameter("cookingTimeMinutes").isEmpty() == false) {
					int s = Integer.parseInt(request.getParameter("cookingTimeMinutes"));
					recipe.setCookingTimeMinutes(s);
				}
				if (request.getParameter("gluten")==null) recipe.setGluten(false);
				else recipe.setGluten(true);
				if (request.getParameter("vegan")==null) recipe.setVegan(false);
				else recipe.setVegan(true);
				if (request.getParameter("imageurl").isEmpty() == false) {
					recipe.setImageURL(request.getParameter("imageurl"));
				}
				recipe.setDifficulty(Integer.parseInt(request.getParameter("difficulty")));
				if (request.getParameter("tips").isEmpty() == false) {
					recipe.setTips(request.getParameter("tips"));
				}
				recipe.setUploadedBy((String) session.getAttribute("loginValue"));
	//			uploading ingredients
				String[] splitString = request.getParameter("ingredients").split(",");
				Integer[] ingIDs = new Integer[splitString.length];
				boolean allIngInDatabase = true;
				for (int i=0; i<splitString.length; i++) {
					int temp = recipe.setIngredient(splitString[i]);
					if (temp == -1) {
						allIngInDatabase = false;
						i = splitString.length;
					}
					else {
						int ingID = temp;
						ingIDs[i] = temp;
					}
				}
				if (allIngInDatabase == false) {
					RequestDispatcher view = request.getRequestDispatcher(RECIPE_ERROR);
					view.forward(request, response);
				}
				else {
					List<Recipe> allRecipes = new ArrayList<Recipe>();
					allRecipes = dao.getAllRecipes();
					int newRecipeID = allRecipes.size() + 1;
					recipe.setRecipeID(newRecipeID);
					dao.addRecipe(recipe);
	
					//add to recipesingredients with ingID and recipeID
					for (int j=0; j<ingIDs.length; j++) {
							ridao.addIngredientToRecipe(ingIDs[j], newRecipeID);
						}
					
					RequestDispatcher view = request.getRequestDispatcher(THANK_YOU);
					request.setAttribute("recipes", dao.getAllRecipes());
					view.forward(request, response);
				}
			}
		} else if (request.getParameter("edit").isEmpty() == false) {
//			here
		}

	}
}