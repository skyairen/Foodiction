package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.RecipeDao;
import com.mie.model.Recipe;
import com.mie.dao.IngredientDao;
import com.mie.model.Ingredient;
import com.mie.dao.UserDao;
import com.mie.model.User;


public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String LOG_IN_SUCCESSFUL= "/log_in_successful.jsp";
	private static String LOG_IN_UNSUCCESSFUL = "/log_in_unsuccessful.jsp";
	private static String ALREADY_LOG = "/log_in_already.jsp";
	private UserDao uDao;


	public LoginController() {
		super();
		uDao = new UserDao();
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		
		forward = LOG_IN_UNSUCCESSFUL;

//		if (action.equalsIgnoreCase("delete")) {
//			int recipeID = Integer.parseInt(request.getParameter("recipeId"));
//			dao.deleteRecipe(recipeID);
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else if (action.equalsIgnoreCase("edit")) {
//			forward = INSERT_OR_EDIT;
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			User user = dao.getUserById(userId);
//			request.setAttribute("user", user);
//		} else if (action.equalsIgnoreCase("listRecipe")) {
//			forward = LIST_RECIPE;
//			request.setAttribute("users", dao.getAllRecipes());
//		} else {
//			forward = "";
//		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}
		

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		User user = new User();
		HttpSession session = request.getSession();
		
		 String storedLogin = (String)session.getAttribute("loginValue");
		 
		 if (storedLogin == null){
				// no value was stored in the session
				// assuming new user is logging in
				// check their credentials
				String loginParameter = request.getParameter("loginParameter");
				String pswdParameter = request.getParameter("pswdParameter");
				
				user = uDao.getUserByUsername(loginParameter);
				
				if(user.getusername() == null) {
					RequestDispatcher view = request.getRequestDispatcher(LOG_IN_UNSUCCESSFUL);
					view.forward(request, response);
					
				}
				
				else if(user.getpassword().equals(pswdParameter) ) {
					// login success!
					// save their session
					
					RequestDispatcher view = request.getRequestDispatcher(LOG_IN_SUCCESSFUL);
					session.setAttribute("loginValue", loginParameter);
					view.forward(request, response);
					
					} 
				
				else {
					// login failed
					RequestDispatcher view = request.getRequestDispatcher(LOG_IN_UNSUCCESSFUL);
					view.forward(request, response);
				}
				
		 } else {
			 
			 RequestDispatcher view = request.getRequestDispatcher(ALREADY_LOG);
			 view.forward(request, response);
			 
	}
		 
				
	}
}