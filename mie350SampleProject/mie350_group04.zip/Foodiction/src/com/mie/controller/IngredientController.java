package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.IngredientDao;
import com.mie.model.Ingredient;
import com.mie.model.Recipe;

public class IngredientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/ingredient.jsp";
	private static String LIST_INGREDIENT = "/ingredient.jsp";
	private static String SEARCH_INGREDIENT = "/ingredient.jsp";
	private static String UPLOAD_ING_ERROR = "/upload_ingredient_error.jsp";
	private static String THANK_YOU = "/upload_ingredient_success.jsp";
	private IngredientDao dao;

	public IngredientController() {
		super();
		dao = new IngredientDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("delete")) {
			int IngredientID = Integer.parseInt(request.getParameter("IngredientID"));
			dao.deleteIngredient(IngredientID);
			forward = LIST_INGREDIENT;
			request.setAttribute("Ingredient", dao.getAllIngredients());
		} else if (action.equalsIgnoreCase("edit")) {
			forward = INSERT_OR_EDIT;
			int IngredientID = Integer.parseInt(request.getParameter("IngredientID"));
			Ingredient ing = dao.getIngredientById(IngredientID);
			request.setAttribute("Ingredient", ing);
		} else if (action.equalsIgnoreCase("listIngredient")) {
			forward = LIST_INGREDIENT;
//			request.setAttribute("Ingredient", dao.getAllIngredients());
			int ingID = Integer.parseInt(request.getParameter("IngredientID"));
			Ingredient ingredient = dao.getIngredientById(ingID);
			request.setAttribute("ingredient", ingredient);
		} else {
			forward = INSERT_OR_EDIT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Ingredient ing = new Ingredient();
		if (request.getParameter("name").isEmpty() == true || 
				request.getParameter("grams").isEmpty() == true || 
				request.getParameter("calories").isEmpty() == true || 
				request.getParameter("carbs").isEmpty() == true || 
				request.getParameter("cholesterol").isEmpty() == true || 
				request.getParameter("sodium").isEmpty() == true || 
				request.getParameter("sugar").isEmpty() == true || 
				request.getParameter("fat").isEmpty() == true || 
				request.getParameter("protein").isEmpty() == true) {
			RequestDispatcher view = request.getRequestDispatcher(UPLOAD_ING_ERROR);
			view.forward(request, response);
		} else {
			ing.setName(request.getParameter("name"));
			ing.setGrams(Integer.parseInt(request.getParameter("grams")));
			ing.setCalories(Integer.parseInt(request.getParameter("calories")));
			ing.setCarbohydrate(Double.parseDouble(request.getParameter("carbs")));
			ing.setCholesterol(Double.parseDouble(request.getParameter("cholesterol")));
			ing.setSodium(Double.parseDouble(request.getParameter("sodium")));
			ing.setSugar(Double.parseDouble(request.getParameter("sugar")));
			ing.setFat(Double.parseDouble(request.getParameter("fat")));
			ing.setProtein(Double.parseDouble(request.getParameter("protein")));
			ing.setVA(Boolean.parseBoolean(request.getParameter("vA")));
			ing.setVB(Boolean.parseBoolean(request.getParameter("vB")));
			ing.setVC(Boolean.parseBoolean(request.getParameter("vC")));
			ing.setVD(Boolean.parseBoolean(request.getParameter("vD")));
			ing.setCalcium(Boolean.parseBoolean(request.getParameter("calcium")));
			ing.setIron(Boolean.parseBoolean(request.getParameter("iron")));
			List<Ingredient> allIngredients = new ArrayList<Ingredient>();
			allIngredients = dao.getAllIngredients();
			int newID = allIngredients.size() + 101;
			ing.setIngredientID(newID);
			dao.addIngredient(ing);
			RequestDispatcher view = request.getRequestDispatcher(THANK_YOU);
			request.setAttribute("ingredients", dao.getAllIngredients());
			view.forward(request, response);
		}
	}
}