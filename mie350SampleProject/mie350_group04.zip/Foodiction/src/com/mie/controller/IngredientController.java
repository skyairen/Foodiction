package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.IngredientDao;
import com.mie.model.Ingredient;

public class IngredientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/ingredient.jsp";
	private static String LIST_INGREDIENT = "/z_old_listIngredient.jsp";
	private static String SEARCH_INGREDIENT = "/ingredient.jsp";
	private IngredientDao dao;

	public IngredientController() {
		super();
		dao = new IngredientDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("delete")) {
			int IngredientID = Integer.parseInt(request.getParameter("IngredientID"));
			dao.deleteIngredient(IngredientID);
			forward = LIST_INGREDIENT;
			request.setAttribute("Ingredient", dao.getAllIngredients());
		} else if (action.equalsIgnoreCase("edit")) {
			forward = INSERT_OR_EDIT;
			int IngredientID = Integer.parseInt(request.getParameter("IngredientID"));
			Ingredient ing = dao.getIngredientById(IngredientID);
			request.setAttribute("Ingredient", ing);
		} else if (action.equalsIgnoreCase("listIngredient")) {
			forward = LIST_INGREDIENT;
			request.setAttribute("Ingredient", dao.getAllIngredients());
		} else {
			forward = INSERT_OR_EDIT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Ingredient ing = new Ingredient();
		ing.setIngredientID(Integer.parseInt(request.getParameter("IngredientID")));
		ing.setName(request.getParameter("Name"));
		ing.setGrams(Integer.parseInt(request.getParameter("Grams")));
		ing.setCalories(Integer.parseInt(request.getParameter("Calories")));
		ing.setCarbohydrate(Double.parseDouble(request.getParameter("Carbohydrate")));
		ing.setCholesterol(Double.parseDouble(request.getParameter("Cholesterol")));
		ing.setSodium(Double.parseDouble(request.getParameter("Sodium")));
		ing.setSugar(Double.parseDouble(request.getParameter("Sugar")));
		ing.setFat(Double.parseDouble(request.getParameter("Fat")));
		ing.setProtein(Double.parseDouble(request.getParameter("Protein")));
		ing.setGluten(Boolean.parseBoolean(request.getParameter("gluten")));
		ing.setVA(Boolean.parseBoolean(request.getParameter("VitaminA")));
		ing.setVB(Boolean.parseBoolean(request.getParameter("VitaminB")));
		ing.setVC(Boolean.parseBoolean(request.getParameter("VitaminC")));
		ing.setVD(Boolean.parseBoolean(request.getParameter("VitaminD")));
		ing.setCalcium(Boolean.parseBoolean(request.getParameter("Calcium")));
		ing.setIron(Boolean.parseBoolean(request.getParameter("Iron")));
		dao.updateIngredient(ing);
		RequestDispatcher view = request.getRequestDispatcher(LIST_INGREDIENT);
		request.setAttribute("users", dao.getAllIngredients());
		view.forward(request, response);
	}
}