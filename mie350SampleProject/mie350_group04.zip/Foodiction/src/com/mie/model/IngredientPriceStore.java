package com.mie.model;

public class IngredientPriceStore {
	private int ingredientId;
	private int price;
	private int storeId;
	private String ingredientName;
	
	public int getIngredientID() {
		return ingredientId;
	}
	
	public String getIngredientName() {
		return this.ingredientName;
	}
	
	public int getPrice() {
		return price;
	}
	
	public int getStoreID() {
		return storeId;
	}
	
	public void setIngredientID(int i) {
		this.ingredientId = i;
	}
	
	public void setPrice(int p) {
		this.price = p;
	}
	
	public void setStoreID(int s) {
		this.storeId = s;
	}
	
	public void setIngredientName(String name) {
		this.ingredientName = name;
	}
}
