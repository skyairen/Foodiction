package com.mie.model;

public class IngredientPriceStore {
	private int ingredientId;
	private int price;
	private int storeId;
	
	public int getIngredientID() {
		return ingredientId;
	}
	
	public int getPrice() {
		return price;
	}
	
	public int getStoreID() {
		return storeId;
	}
	
	public void setIngredientID(int i) {
		this.ingredientId = i;
	}
	
	public void setPrice(int p) {
		this.price = p;
	}
	
	public void setStoreID(int s) {
		this.storeId = s;
	}
}
