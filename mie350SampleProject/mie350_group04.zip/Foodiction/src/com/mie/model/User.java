package com.mie.model;

import java.util.Date;
import java.text.SimpleDateFormat;

public class User {
	private String username;
	private String password;
	private String email;
	private Date dob;
	private String profession;
	private String foodTypePreference;
	private int location;
	
	public String getusername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username= username;
	}
	
	public String getpassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getFoodTypePreference() {
		return foodTypePreference;
	}

	public void setFoodTypePreference(String foodTypePreference) {
		this.foodTypePreference = foodTypePreference;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public void setLocation(int location) {
		this.location = location;
	}
	
	public int getLocation() {
		return location;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

/*	@Override
	public String toString() {
		return "User [userid=" + userid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", email="
				+ email + ", address=" + address + ""]";"
	}
*/
}