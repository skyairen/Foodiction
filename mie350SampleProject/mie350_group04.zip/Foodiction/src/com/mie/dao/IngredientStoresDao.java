package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Ingredient;
import com.mie.model.IngredientPriceStore;
import com.mie.model.Store;
import com.mie.model.Ingredient;
import com.mie.util.DbUtil;

public class IngredientStoresDao {

	private Connection connection;

	public IngredientStoresDao() {
		connection = DbUtil.getConnection();
	}
	
	public void addIngredientToStore(int ingredientId, int storeId, int price) {
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into ingredientsStores(StoreID,IngredientID,Price) values (?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setInt(1, storeId);
			preparedStatement.setInt(2, ingredientId);
			preparedStatement.setDouble(3, price);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		
	
	public void deleteIngredientFromStore(int ingredientId, int storeId) {
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from ingredientsStores where StoreID=? AND IngredientID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, storeId);
			preparedStatement.setInt(2, ingredientId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

		
	
	public List<Ingredient> getAllIngredientsInStore(int storeId) {
		
		List<Ingredient> ingredients = new ArrayList<Ingredient>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from ingredientsStores where StoreID=?");
			preparedStatement.setInt(1, storeId);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Ingredient ingredient  = new Ingredient();
				ingredient.setIngredientID(rs.getInt("IngredientID"));
				//ingredient.setPrice(rs.getDouble("Price")); WE NEED THE PRICE IN INGREDIENTS
				
				ingredients.add(ingredient);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ingredients;
		
	}
	
	public List<Store> getAllStoresWithIngredient(int ingredientId) {
		
		List<Store> stores = new ArrayList<Store>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from ingredientsStores where IngredientID=?");
			preparedStatement.setInt(1, ingredientId);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				Store store  = new Store();
				store.setStoreID(rs.getInt("StoreID"));
				//Store.setPrice(rs.getDouble("Price")); WE NEED THE PRICE IN INGREDIENTS
				
				stores.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return stores;
		
	}

	//enter list of Ingredient objects to return list of ingredients, prices, and store of the closest ingredients
	
	//i.e. {1001, 101, 4} for {Metro, salt, $4}
	public List<IngredientPriceStore> getClosestIngredients (int recipeID, int location) {
		List<IngredientPriceStore> ingredientsList = new ArrayList<IngredientPriceStore>();
		
		List<Store> closestStores = new ArrayList<Store>();
		StoresDao store = new StoresDao();
		closestStores = store.getClosestStores(location);				//fetch all the closest stores and store to list
		
		List<Ingredient> ingredients = new ArrayList<Ingredient>();
		RecipeDao recipe = new RecipeDao();
		ingredients = recipe.getAllIngredientsInRecipe(recipeID);		//fetch all ingredients in recipe and store to list
		
		//go through for all ingredients, find all of them in the nearest stores
		for (Store s : closestStores) {
			for (Ingredient i : ingredients) {
				try {
					PreparedStatement preparedStatement = connection
							.prepareStatement("SELECT * FROM IngredientsStores WHERE StoreId = ? AND IngredientID = ?");
					preparedStatement.setInt(1, s.getStoreID());
					preparedStatement.setInt(2, i.getIngredientID());
					ResultSet rs = preparedStatement.executeQuery();
					
					while (rs.next()) {
						IngredientPriceStore ips = new IngredientPriceStore();
						
						ips.setIngredientID(rs.getInt("IngredientID"));
						ips.setPrice(rs.getInt("Price"));
						ips.setStoreID(rs.getInt("StoreID"));
						
						//collect ingredient name, price, and store 
						ingredientsList.add(ips);
					}
				} 
				
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return ingredientsList;
	}
}

//get store and price given ID

//object pricesAndStore

//string ingrediantName
//arraylist stores
//arraylist prices;

//store[0] = 'Loblaws'
//store[1] = 'metro'

//price[0] = 4
//price[1] = 3.5
