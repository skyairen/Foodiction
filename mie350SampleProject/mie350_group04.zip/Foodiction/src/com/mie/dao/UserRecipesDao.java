package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.User;
import com.mie.model.Recipe;
import com.mie.util.DbUtil;

public class UserRecipesDao {

	private Connection connection;

	public UserRecipesDao() {
		connection = DbUtil.getConnection();
	}
	
	public void addRecipeByUser(int recipeId, String username) {
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into UserRecipes(UserName,RecipeID) values (?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, recipeId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		}
	
	public void deleteRecipeByUser(int recipeId, String username) {
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from UserRecipes where UserName=? AND RecipeID=?");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, recipeId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public List<Recipe> getAllRecipesByUser(String username) {
		
		List<Recipe> recipes = new ArrayList<Recipe>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from UserRecipes where UserName=?");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				Recipe recipe  = new Recipe();
				recipe.setRecipeID(rs.getInt("RecipeID"));
				
				recipes.add(recipe);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipes;
		
	}
	
	public List<Recipe> getMyStars(String Username) {
		List<Recipe> recipes = new ArrayList<Recipe>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT * FROM Recipe INNER JOIN UsersRecipes ON Recipe.RecipeID=UsersRecipes.RecipeID WHERE UserName = ? AND Saved =-1");
			preparedStatement.setString(1, Username);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Recipe recipe = new Recipe();
				recipe.setRecipeID(rs.getInt("recipeid"));
				recipe.setName(rs.getString("Name"));
				recipe.setFoodType(rs.getString("foodtype"));
				recipe.setGluten(rs.getBoolean("gluten"));
				recipe.setVegan(rs.getBoolean("vegan"));
				recipe.setDifficulty(rs.getInt("difficulty"));
				recipe.setRating(rs.getInt("rating"));
				recipe.setFavorites(rs.getInt("favorites"));
				recipe.setImageURL(rs.getString("imageurl"));
//				user.setLastName(rs.getString("lastname"));
//				user.setDob(rs.getDate("dob"));
//				user.setEmail(rs.getString("email"));
				recipes.add(recipe);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipes;
	}
	
	public List<Recipe> getMyUploads(String Username) {
		List<Recipe> recipes = new ArrayList<Recipe>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT * FROM Recipe WHERE UploadedBy =?");
			preparedStatement.setString(1, Username);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Recipe recipe = new Recipe();
				recipe.setRecipeID(rs.getInt("recipeid"));
				recipe.setName(rs.getString("Name"));
				recipe.setFoodType(rs.getString("foodtype"));
				recipe.setGluten(rs.getBoolean("gluten"));
				recipe.setVegan(rs.getBoolean("vegan"));
				recipe.setDifficulty(rs.getInt("difficulty"));
				recipe.setRating(rs.getInt("rating"));
				recipe.setFavorites(rs.getInt("favorites"));
				recipe.setImageURL(rs.getString("imageurl"));

				recipes.add(recipe);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipes;
	}
public void RateRecipe(String username, int recipeId, int Rating){
		
		String UserName = "";
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * FROM UsersRecipes WHERE UserName=? AND RecipeID=?");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, recipeId);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				UserName = rs.getString("UserName");
				int Recipe = rs.getInt("RecipeID");
					
				}
				
			
			
		
			//check if table retrieved a tuple, if it didn't then recipe is not rated, rate it
			if(!UserName.equalsIgnoreCase(username)){
				PreparedStatement preparedStatement2 = connection
						.prepareStatement("insert into UsersRecipes(UserName,RecipeID,Rating) values (?, ?, ?)");
				// Parameters start with 1
				preparedStatement2.setString(1, username);
				preparedStatement2.setInt(2, recipeId);
				preparedStatement2.setInt(3, Rating);
				preparedStatement2.executeUpdate();
				
				
			}
			
			else {
				PreparedStatement preparedStatement3 = connection
						.prepareStatement("UPDATE UsersRecipes SET RATING =? WHERE UserName=? AND RecipeID =?");
				// Parameters start with 1
				preparedStatement3.setInt(1, Rating);
				preparedStatement3.setString(2, username);
				preparedStatement3.setInt(3, recipeId);
				preparedStatement3.executeUpdate();
				
				
			}
			
			
		

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ;
	}

public int SaveRecipe(String username, int recipeId){
	boolean Save = true;
	int Saved = 0;
	int fave = 2;
	String UserName = "";
	try {
		PreparedStatement preparedStatement = connection
				.prepareStatement("select * FROM UsersRecipes WHERE UserName=? AND RecipeID=?");
		// Parameters start with 1
		preparedStatement.setString(1, username);
		preparedStatement.setInt(2, recipeId);
		ResultSet rs = preparedStatement.executeQuery();
		
		while (rs.next()) {
			UserName = rs.getString("UserName");
			int Recipe = rs.getInt("RecipeID");
			fave = rs.getInt("Saved");
				
			}
			
		
		
		System.out.println(fave);
		//check if table retrieved a tuple, if it didn't then recipe is not saved, save it
		if(!UserName.equalsIgnoreCase(username)){
			PreparedStatement preparedStatement2 = connection
					.prepareStatement("insert into UsersRecipes(UserName,RecipeID,Saved) values (?, ?, ?)");
			// Parameters start with 1
			preparedStatement2.setString(1, username);
			preparedStatement2.setInt(2, recipeId);
			preparedStatement2.setBoolean(3, true);
			preparedStatement2.executeUpdate();
			
			Saved = 1;
			
		}
		
		else if(fave == 0){
			PreparedStatement preparedStatement3 = connection
					.prepareStatement("UPDATE UsersRecipes SET SAVED =-1 WHERE UserName=? AND RecipeID =?");
			// Parameters start with 1
			preparedStatement3.setString(1, username);
			preparedStatement3.setInt(2, recipeId);
			preparedStatement3.executeUpdate();
			
			Saved = 1;
			
		}
		
		else {
			Saved = 2;
		}
	

	} catch (SQLException e) {
		e.printStackTrace();
	}

	return Saved;
}

	
}