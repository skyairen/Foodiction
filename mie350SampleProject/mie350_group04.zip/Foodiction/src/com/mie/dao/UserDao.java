package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.User;
import com.mie.util.DbUtil;

public class UserDao {

	private Connection connection;

	public UserDao() {
		connection = DbUtil.getConnection();
	}

	public void addUser(User user) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into users(username,password,email,dateofbirth,profession,foodtypepreferences,location) values (?, ?, ?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setString(1, user.getusername());
			preparedStatement.setString(2, user.getpassword());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setDate(4, new java.sql.Date(user.getDob()
					.getTime()));
			preparedStatement.setString(5, user.getProfession());
			preparedStatement.setString(6, user.getFoodTypePreference());
			preparedStatement.setInt(7, user.getLocation());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(int username) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from users where username=?");
			// Parameters start with 1
			preparedStatement.setInt(1, username);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateUser(User user) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update users set password=?, email=?, dateofbirth=?, profession=?, foodtypepreference=?, location=?"
							+ " where username=?");
			// Parameters start with 1
			preparedStatement.setString(1, user.getpassword());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setDate(3, new java.sql.Date(user.getDob()
					.getTime()));
			preparedStatement.setString(4, user.getProfession());
			preparedStatement.setString(5, user.getFoodTypePreference());
			preparedStatement.setInt(6, user.getLocation());
			preparedStatement.setString(7, user.getusername());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<User> getAllUsers() {
		List<User> users = new ArrayList<User>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from users");
			while (rs.next()) {
				User user = new User();
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setDob(rs.getDate("dateofbirth"));
				user.setProfession(rs.getString("profession"));
				user.setFoodTypePreference(rs.getString("foodtypepreference"));
				user.setLocation(rs.getInt("location"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	
	public boolean checkEmail (List<User> users, String email) {
		boolean check = false;
		for (User user : users) {
			if (user.getEmail() == email) {
				check = true;
				return check;
			}
		}
		return check;
	}
	
	public boolean checkUsername (List<User> users, String username) {
		boolean check = false;
		for (User user : users) {
			if (user.getusername() == username) {
				check = true;
				return check;
			}
		}
		return check;
	}

	public User getUserByUsername(String username) {
		User user = new User();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from users where username=?");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setDob(rs.getDate("dateofbirth"));
				user.setProfession(rs.getString("profession"));
				user.setFoodTypePreference(rs.getString("foodtypepreference"));
				user.setLocation(rs.getInt("location"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return user;
	}
	
	public List<User> getUserByKeyword(String keyword) {
		List<User> users = new ArrayList<User>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from users where username LIKE ? OR email LIKE ? OR dateofbirth LIKE ? OR profession LIKE ? OR foodtypepreference LIKE?");
			
//			SELECT title FROM pages WHERE my_col LIKE %$param1% OR another_col LIKE %$param2%;
			
			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			preparedStatement.setString(5, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setDob(rs.getDate("dob"));
				user.setProfession(rs.getString("profession"));
				user.setFoodTypePreference(rs.getString("foodtypepreference"));
				user.setLocation(rs.getInt("location"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	
}