package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Store;
import com.mie.model.User;
import com.mie.util.DbUtil;

public class StoresDao {
	
	private static int MAP_GRID_SIZE = 3;	//size of the grid, in this case 3 x 3
	
	private Connection connection;

	public StoresDao() {
		connection = DbUtil.getConnection();
	}
	
	public void addStore(Store store) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Store(StoreID, Name, Address, PostalCode, Location) "
							+ "values (?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setInt(1, store.getStoreID());
			preparedStatement.setString(2, store.getName());
			preparedStatement.setString(3, store.getAddress());
			preparedStatement.setString(4, store.getPostalCode());
			preparedStatement.setInt(5, store.getLocation());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteStore(int storeId) {
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from Store where StoreID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, storeId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateStore(Store store){
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update Store "
							+ "set StoreID=?, Name=?, Address=?, PostalCode=?, Location=? "
							+ "where StoreID=?");
			preparedStatement.setInt(1, store.getStoreID());
			preparedStatement.setString(2, store.getName());
			preparedStatement.setString(3, store.getAddress());
			preparedStatement.setString(4, store.getPostalCode());
			preparedStatement.setInt(5, store.getLocation());
			preparedStatement.setInt(6, store.getStoreID());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Store> getAllStores() {
		List<Store> stores = new ArrayList<Store>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Stores");
			while (rs.next()) {
				Store store = new Store();
				store.setStoreID(rs.getInt("StoreID"));
				store.setName(rs.getString("Name"));
				store.setAddress(rs.getString("Address"));
				store.setPostalCode(rs.getString("PostalCode"));
				store.setLocation(rs.getInt("Location"));
				stores.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return stores;
	}
	
	public Store getStoreById(int storeId) {
		Store store = new Store();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Stores where StoreID=?");
			preparedStatement.setInt(1, storeId);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				store.setStoreID(rs.getInt("StoreID"));
				store.setName(rs.getString("Name"));
				store.setAddress(rs.getString("Address"));
				store.setPostalCode(rs.getString("PostalCode"));
				store.setLocation(rs.getInt("Location"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return store;
	}
	
	public Store getStoreByName(String name) {
		Store store = new Store();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Stores where Name=?");
			preparedStatement.setString(1, name);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				store.setStoreID(rs.getInt("StoreID"));
				store.setName(rs.getString("Name"));
				store.setAddress(rs.getString("Address"));
				store.setPostalCode(rs.getString("PostalCode"));
				store.setLocation(rs.getInt("Location"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return store;

	}
	
	public List<Store> getStoreByKeyword(String keyword) {
		List<Store> stores = new ArrayList<Store>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Stores where Name LIKE ? OR Address LIKE ? OR PostalCode LIKE ? OR "
							+ "Location LIKE ?"); //after we make the location table, we can include proximity search here
						
			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Store store = new Store();
				store.setStoreID(rs.getInt("StoreID"));
				store.setName(rs.getString("Name"));
				store.setAddress(rs.getString("Address"));
				store.setPostalCode(rs.getString("PostalCode"));
				store.setLocation(rs.getInt("Location"));
				stores.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return stores;
	}
	
	public Store getClosestStore(int location) {
		Store store = new Store();
		int difference=1000;
		
		List<Store> stores = this.getAllStores();
		for (Store storeCounter: stores) {
			if (Math.abs(storeCounter.getLocation()-location)<difference) {//if distance of store is less than existing smallest difference
				difference = Math.abs(storeCounter.getLocation()-location);
				store = storeCounter;
			}
		}
		return store;
	}

	//returns a list of stores objects that are 1 tile away from the entered location
			//diagonal tiles are considered 2 tiles away
//		public List<Store> getClosestStore(int location) {
//			List<Store> stores = new ArrayList<Store>();
//			List<Integer> potentialStores = new ArrayList<Integer>();
//			
//			if (location < 1 || location > (MAP_GRID_SIZE * MAP_GRID_SIZE)) {
//				//if the user location isnt within the grid
//				return stores;
//			}
//			
//			//try all tiles within grid
//			//i.e. grid:
//			//			1 2 3
//			//			4 5 6
//			//			7 8 9
//			for (int i = 1; i <= (MAP_GRID_SIZE * MAP_GRID_SIZE); i++) {
//				if (((i - 1) % MAP_GRID_SIZE) != 0) {		//i.e. make sure to not add 4 if location is 3
//					potentialStores.add(i - 1);
//				}
//				
//				if ((i % MAP_GRID_SIZE) != 0) {				//i.e. make sure to not add 3 if location is 4
//					potentialStores.add(i + 1);
//				}
//				
//				potentialStores.add(i - MAP_GRID_SIZE);		//i.e. add 1 if location is 4
//				potentialStores.add(i + MAP_GRID_SIZE);		//i.e. add 7 if location is 4
//			}
//			
//			for (int storeLocation : potentialStores) {
//				//add list of closest locations
//				if (storeLocation > 0 && storeLocation < (MAP_GRID_SIZE * MAP_GRID_SIZE)) {
//					//if the store exists, add it
//					if (this.exists(storeLocation)) {
//						stores.add(this.getStoreByLocation(storeLocation));
//					}
//				}
//			}
//			
//			return stores;
//		}
		
		public Store getStoreByLocation(int location) {
			Store store = new Store();
			
			try {
				PreparedStatement preparedStatement = connection.prepareStatement("select * from Stores where location = '" + location + "'");
				ResultSet rs = preparedStatement.executeQuery();
				
				if (rs.next()) {
					if (rs.next()) {
						store.setStoreID(rs.getInt("StoreID"));
						store.setName(rs.getString("Name"));
						store.setAddress(rs.getString("Address"));
						store.setPostalCode(rs.getString("PostalCode"));
						store.setLocation(rs.getInt("Location"));
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return store;
		}
		
		//check if a store exists by its ID
		public boolean exists(int storeId) {
			try {
				PreparedStatement preparedStatement = connection.prepareStatement("select * from Stores where StoreID = '" + storeId + "'");
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					return true;
				}
				
				else {
					return false;
				}
			} 
			
			catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
}
