package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.mie.model.User;
import com.mie.util.DbUtil;

public class UserDao {

	private Connection connection;

	public UserDao() {
		connection = DbUtil.getConnection();
	}

	public void addUser(User user) {
		
	}

	public void deleteUser(int userId) {
		
	}

	public void updateUser(User user) {
		
	}

	public List<User> getAllUsers() {
		
	}

	public User getUserById(int userId) {
		
	}
	
	public List<User> getUserByKeyword(String keyword) {
		
	}
	
}