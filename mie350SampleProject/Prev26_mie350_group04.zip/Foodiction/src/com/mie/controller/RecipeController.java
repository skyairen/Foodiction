package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.RecipeDao;
import com.mie.dao.RecipesIngredientsDao;
import com.mie.dao.UserRecipesDao;
import com.mie.model.Recipe;
import com.mie.dao.IngredientDao;

public class RecipeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/user.jsp";
	private static String LIST_RECIPE = "/recipe.jsp";
	private static String THANK_YOU = "/thankyou.jsp";
	private static String SEARCH_FNAME_USER = "/searchFNUser.jsp";
	private static String MY_STAR = "/my_star.jsp";
	private static String MY_UPLOAD = "/my_upload.jsp";
	private RecipeDao dao;
	private UserRecipesDao URdao;
	private RecipesIngredientsDao ridao;
	private IngredientDao idao;

	public RecipeController() {
		super();
		dao = new RecipeDao();
		URdao = new UserRecipesDao();
		ridao = new RecipesIngredientsDao();
		idao = new IngredientDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		HttpSession session = request.getSession();

		if (action.equalsIgnoreCase("delete")) {
//			int userId = Integer.parseInt(request.getParameter("userId"));
//			dao.deleteUser(userId);
//			forward = LIST_USER;
//			request.setAttribute("users", dao.getAllUsers());
		} else if (action.equalsIgnoreCase("edit")) {
			forward = INSERT_OR_EDIT;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
		} else if (action.equalsIgnoreCase("listRecipe")) {
			forward = LIST_RECIPE;
			int recipeId = Integer.parseInt(request.getParameter("recipeID"));
			Recipe recipe = dao.getRecipeById(recipeId);
			request.setAttribute("recipe", recipe);
			request.setAttribute("ingredient", ridao.getAllIngredientsInRecipe(recipeId));
//			request.setAttribute("recipes", dao.getAllRecipes());
		} else if(action.equalsIgnoreCase("ListMyStar")) {
			forward = MY_STAR;
			String Username = (String) session.getAttribute("loginValue");	
			request.setAttribute("mystars", URdao.getMyStars(Username));
			
		} else if(action.equalsIgnoreCase("ListMyUpload")) {
			forward = MY_UPLOAD;
			String Username = (String) session.getAttribute("loginValue");	
			request.setAttribute("myuploads", URdao.getMyUploads(Username));
			
		}
		else {
			forward = INSERT_OR_EDIT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Recipe recipe = new Recipe();
		String recipeid = request.getParameter("recipeid");
		recipe.setName(request.getParameter("name"));
		recipe.setImageURL(request.getParameter("imageurl"));
		if (request.getParameter("gluten")==null)
			recipe.setGluten(false);
		else
			recipe.setGluten(true);
		if (request.getParameter("vegan")==null)
			recipe.setVegan(false);
		else
			recipe.setVegan(true);
		recipe.setServings(Integer.parseInt(request.getParameter("servings")));
		recipe.setFoodType(request.getParameter("foodType"));
		recipe.setPrepTimeMinutes(Integer.parseInt(request.getParameter("prepTimeMinutes")));
		recipe.setCookingTimeMinutes(Integer.parseInt(request.getParameter("cookingTimeMinutes")));
		recipe.setDifficulty(Integer.parseInt(request.getParameter("difficulty")));
		recipe.setTips(request.getParameter("tips"));
		recipe.setDirections(request.getParameter("directions"));
		recipe.setUploadedBy((String) session.getAttribute("loginValue"));
		
		//upload ingredients
		String[] splitString = request.getParameter("ingredients").split(",");
		Integer[] ingIDs = new Integer[splitString.length];
		RequestDispatcher view;
		
		for (int i=0; i<splitString.length; i++) {
			int ingredientID;
			try {
			//add ingredient to recipe.ingredientlist and retrieve ingredient's ID
			ingredientID = recipe.setIngredient(splitString[i]);
			//save ingredient's id
			ingIDs[i] = ingredientID;
			view = request.getRequestDispatcher(THANK_YOU);
			}
			catch (NullPointerException e) {
//				request.setAttribute("ingredientID", ingredientID);
				e.printStackTrace();
				view = request.getRequestDispatcher("/upload_recipe_error.jsp");
			}
		}
//		int ingredientID = recipe.setIngredient(request.getParameter("ingredient"));
		

		
//		if (recipeid == null || recipeid.isEmpty()) {
		
		//add recipe to database
		dao.addRecipe(recipe);
		//retrieve recipe complete with ID
		Recipe finished = dao.getRecipeByName(recipe.getName());
		int fID = finished.getRecipeID();
		
		for (int j=0; j<ingIDs.length; j++) {
		//add to recipesingredients with ingID and recipeID
			ridao.addIngredientToRecipe(ingIDs[j], fID);
		}
		
//		} else {
//			recipe.setRecipeID(Integer.parseInt(recipeid));
//			dao.updateRecipe(recipe); //TODO
//		}
		view = request.getRequestDispatcher(THANK_YOU);
		request.setAttribute("recipes", dao.getAllRecipes());
		view.forward(request, response);
	}
}