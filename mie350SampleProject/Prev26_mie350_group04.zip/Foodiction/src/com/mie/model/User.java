package com.mie.model;

import java.util.Date;

public class User {
	private String password;
	private String username;
	private int userid;
	private String firstName;
	private String lastName;
	private Date dob;
	private String email;
	private String address;

	public int getUserid() {
		return userid;
	}
	
	public String getusername() {
		return username;
	}
	
	public String getpassword() {
		return password;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public String getAddress() {
		return address;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setUsername(String username) {
		this.username= username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

/*	@Override
	public String toString() {
		return "User [userid=" + userid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", email="
				+ email + ", address=" + address + ""]";"
	}
*/
}